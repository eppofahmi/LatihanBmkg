library(tidyverse)
library(lubridate)

datacuaca_aus = readr::read_csv(file = "data/mentah/weather AUS.csv")
glimpse(datacuaca_aus)

# PR 3 ------
obj9 <- datacuaca_aus %>% 
  # pilih kolom 1:5
  dplyr::select(1:5) %>% 
  # pilih baris yang bulan ke 5 saja
  dplyr::filter(month(Date) == 5) %>%  
  dplyr::filter(!is.na(MinTemp)) %>% 
  # membuat kolom baru berdasarkan kolom lokasi
  dplyr::group_by(Location) %>% 
  mutate(Rerata = mean(MinTemp))

summary(obj9)

# Day-3 --------------------------------------------------
## Row names to column
data1 = mtcars
has_rownames(data1) # TRUE

data1 = data1 %>% 
  rownames_to_column("NamaMobil")
has_rownames(data1) # FALSE

?rownames_to_column

## Memisah dan Menggabungkan Kolom
### Memisahkan separate()
Sys.Date() # ymd
Sys.time() # ymd hms

obj1a = datacuaca_aus %>% 
  tidyr::separate(col = Date, into = c("Tahun", "Bulan", "Tanggal"), sep = "-", remove = FALSE)

t1 = data.frame(Date = as.character(Sys.time()))
class(t1)

separate(t1, Date, into = c("Tanggal", "Jam"), sep = " ")
glimpse(obj1a)

obj1a$Tahun = as.double(obj1a$Tahun)
obj1a$Bulan = as.double(obj1a$Bulan)
obj1a$Tanggal = as.double(obj1a$Tanggal)
glimpse(obj1a)

obj1a$DateNum = as.integer(obj1a$Date)
glimpse(obj1a)

# Boleh minta contoh cara filter nilai dengan kriteria tertentu menjadi NA? Misalkan MinTemp > 20 jadi NA

obj1b = obj1a %>% 
  dplyr::filter(MinTemp > 20) %>% 
  dplyr::mutate(MinTemp = NA)

obj1b = obj1a %>% 
  mutate(MinTemp = case_when(
    MinTemp > 20 ~ 100, 
    TRUE ~ MinTemp
  ))

### Menggabungkan kolom -> unite()
obj1c = obj1a %>% 
  ungroup() %>% 
  tidyr::unite(col = "Date2", Tahun:Tanggal, sep = " dan ")

obj1c$newVar = paste(obj1c$RainTomorrow, "dan", obj1c$DateNum)
glimpse(obj1c)

# paste()
# paste0()
obj1d = obj1c %>% 
  ungroup() %>% 
  select(-c(DateNum, newVar))

## Merangkum data
obj5 = datacuaca_aus %>% 
  mutate(Tahun = year(Date)) %>% 
  group_by(Location, RainTomorrow) %>% 
  count(Tahun) 

obj6 = datacuaca_aus %>% 
  filter(year(Date) == 2008) %>% 
  filter(Rainfall >= 50)

# ambil data teratas sejumlah n
obj7 = obj6 %>% 
  head(2)

# ambil data terbawah sejumlah n
obj7 = obj6 %>% 
  tail(2)

# sorting/mengurutkan dari besar/kecil atau sebaliknya
obj6 = obj6 %>% 
  arrange(desc(Rainfall))

obj6 = obj6 %>% 
  arrange(Rainfall)

for (i in seq_along(1:nrow(obj6))) {
  print(paste0("Baris ke-", i))
  if(obj6$MinTemp[i] <= 15){
    obj6$koreksiMinTemp[i] = obj6$MinTemp[i] + 100
  } else {
    obj6$koreksiMinTemp[i] = obj6$MinTemp[i]
  }
}

# Hal di atas bisa juga dikerjakan dengan case_when. Tapi tidak bisa dengan cara membuat kolom langsung
obj6$koreksiMinTemp = obj6$MinTemp + 100

## Visualisasi dengan GGPLOT2 ----
# GG = grammar of graphic (sumbu x,y + z, tipe plot)

# 1. Menunjukkan Hubungan (scatter)
# 2. Menunjukkan Distribusi (line plot/diagram balok)
# 3. Menunjukkan Komposisi (Pie/diagram balok)
# 4. Menunjukkan Perbandingan (Digaram balok)

### Distribusi

### Tujuan: memberikan informasi tentang distribusi data dalam tahun tertentu
## data
datacuaca_aus %>% 
  mutate(Tahun = year(Date)) %>% 
  count(Tahun)

datavis1 = datacuaca_aus %>% 
  mutate(Tahun = year(Date)) %>% 
  count(Tahun)

datavis1$Tahun = as.character(datavis1$Tahun)

datavis1a = datavis1 %>% 
  filter(n == min(n) | n == max(n))

datavis1 %>% 
  ggplot(aes(x = Tahun, y = n)) + 
  geom_col()

personal_theme = theme(plot.title = element_text(hjust = 0.5))

datavis1 %>% 
  ggplot(aes(x = Tahun, y = n, group = 1)) + 
  geom_line() + 
  geom_text(data = datavis1a, aes(x = Tahun, y = n, label = n)) + 
  theme(plot.title = element_text(hjust = 0.5)) + 
  labs(title = "Judul Plot")

p1 = datacuaca_aus %>% 
  mutate(Tahun = year(Date)) %>% 
  count(Tahun) %>% 
  ggplot(aes(x = Tahun, y = n)) +
  geom_col() +
  ggtitle("Distribusi Data") + 
  labs(x = "Year", y = "Total")

class(p1)

# https://bbc.github.io/rcookbook/#how_to_create_bbc_style_graphics
datavis1

datavis1 %>% 
  ggplot(aes(x = Tahun, y = n)) + 
  geom_line() + 
  geom_text(aes(label = n)) +
  labs(title = "Distribusi observasi pertahun", x = "Year", y = "Total", 
       caption = "Source: NOAA")

dv1 = datacuaca_aus %>% 
  count(Date)

# dv1$Date = as.character(dv1$Date)

dv1 %>% 
  ggplot(aes(Date, n, group = 1)) + 
  geom_line()

# menyimpan plot terakhir yang dibuat
ggsave(filename = "plot/plot-observasi.png", width = 15, 
       height = 8, units = "cm", dpi = 300)

# menyimpan plot dari sebuah objek
ggsave(plot = p1, filename = "plot/observasi2.png", width = 10, height = 5, units = "cm", dpi = 100)


# membuat boxplot
p2 = datacuaca_aus %>% 
  ggplot(aes(x = Location, y = MaxTemp)) + 
  geom_boxplot(fill = "grey") +
  theme(axis.text.x = element_text(angle = 90))
p2

# menyimpan plot 
# ggsave(filename = "tes", path = "plot")
ggsave("plot/plot-dist1.png", width = 15, height = 8, units = "cm", dpi = 300)
?ggsave
ggsave(plot = p1, "plot/plot-dist1.jpg", width = 8, height = 5, units = "cm", dpi = 72)

# menggunakan tiga variabel 
datacuaca_aus %>% 
  count(Location, WindGustDir)

datacuaca_aus %>% 
  count(Location, WindGustDir) %>% 
  head(100) %>% 
  ggplot(aes(x = WindGustDir, y = n, fill = Location)) + 
  geom_col(position = "dodge")

## ggplot() membuat
## aes() sumbu x dan y, z
## geom() jenis plot

### Mebuat Plot Hubungan 
p3 = datacuaca_aus %>% 
  head(1000) %>% 
  ggplot(aes(x = MinTemp, y = Rainfall)) + 
  geom_point() + 
  geom_smooth()

### Komparasi 
# geom_bar -> observais
?geom_bar

obj5 %>% 
  filter(str_detect(Location, "Woomera|Adelaide")) %>% 
  ggplot(aes(Tahun,)) + 
  geom_bar()

obj5 %>% 
  ungroup() %>% 
  filter(str_detect(Location, "Woomera|Adelaide")) %>% 
  group_by(Location, Tahun) %>% 
  summarise(total = sum(n)) %>% 
  ggplot(aes(x = Tahun, y = total, fill = Location)) + 
  geom_col(position = "dodge") + 
  facet_wrap(~Location, scales = "free")

### gabungan geom_
data1 %>% 
  ggplot(aes(x = NamaMobil, y = log(mpg))) +
  geom_col() + 
  geom_line(data=data1, aes(x = NamaMobil, y = log(disp)), group = 1) + 
  theme(axis.text.x = element_text(angle = 90))

library(dataplot)

# Visualisasi map
data_hujan = read_csv("data/mentah/pch_ensMean.2021.08_ver_2021.02.01.csv")
library(ggmap)
library(dplyr)
?ggmap

library(dataplot)
library(ggplot2)

df <- data.frame("brand" = c("Samsung", "Huawei", "Apple", "Xiaomi", "OPPO"),
                 "share" = c(10, 30, 20, 35, 5)
)
df %>% 
  mutate(total = sum(share)) %>% 
  mutate(persen = share/total * 100)

df1 = obj4 %>% 
  filter(Location == "Adelaide") %>% 
  mutate(total = sum(n)) %>% 
  mutate(persen = n/total * 100)

mycolor <- c("#55DDE0", "#33658A", "#2F4858", "#F6AE2D", "#F26419", 
             "#55DDf1", "#33858A", "#2F4859", "#F5AE2D", "#F26219", 
             "#55DDf1", "#33858A", "#2F4859", "#F5AE2D", "#F26219", 
             "#55DDf1", "#33858A", "#2F4859", "#F5AE2D", "#F26219")

plot_pie(
  data = df1, x = "WindGustDir", y = "n", color = mycolor,
  title = "Lorem Ipsum is simply dummy text",
  subtitle = "Contrary to popular belief, Lorem Ipsum is not simply random text",
  data_source = "Sumber: www.kedata.online")